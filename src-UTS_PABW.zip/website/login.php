<?php
session_start();

//if (isset($_SESSION["login"])) {
  //  header("Location: home.php");
    //exit;
//}
require 'koneksi.php';
    
    if ( isset($_POST["login"]) ) {

      $username = $_POST["username"];
      $password = $_POST["password"];

      $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' AND password = '$password' ");
      $r = mysqli_fetch_array($result);
      $username = $r['username'];
      $password = $r['password'];
      if($username == $username && $password == $password){
        header("location: home.php");
      }else{
        echo "<script>
          alert('zzzzzzzzzzzz');
      </script>";
      }

      
     
     }
?>
<!DOCTYPE html>
<html>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Login</title>
  </head>
  <body>
 
    <header>
      <div class="container">
        <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-white">
  <a class="navbar-brand" href="#">Muhammad Hijrul Arifin Zain</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
		<li class="nav-item active">
        <a class="nav-link" href="index.html">src-UTS to Github<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index.html">Back To Home<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>
      </div>
    </header>
    

<!-- Awal Jumbotron -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid warna-bg text-white">
    <div class="container">
      <h1 class="display-4">LOGIN</h1>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron -->



<!-- Awal Content -->
<div class="container">
  <form action="" method="post">
    <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" id="username" class="form-control">
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" name="password" id="password" class="form-control">
    </div>
    <button type="submit" name="login" class="btn-primary active">
      Login
    </button>
  </form>
   
  Doens't have any account?<a href="register.php">Register here!</a>
</div>

<!-- Akhir Content -->


<!-- Awal Jumbotron2 -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid bg-light text-dark">
    <div class="container">
      <h2>Address</h2>
        <h1 class="lead">Jl. Guna Karya, Pekanbaru</h1>
        <h1 class="lead">South Sumatra, Indonesian</h1>
        <h1 class="lead">Email: zainaja91@gmail.com</h1>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron2 -->

<!-- Awal Footer -->
<footer class="warna-bg">
  <div class="text-white text-center pt-3 pb-3">Copyright @2020 Muhammad Hijrul Arifin Zain</div>
</footer>
<!-- Akhir Footer -->













    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="js/jquery-3.4.1.slim.min.js"></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
  </body>
</html>