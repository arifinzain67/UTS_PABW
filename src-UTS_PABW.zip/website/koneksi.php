<?php
	// koneksi ke database
	$conn = mysqli_connect("localhost", "mharifin", "bPii7_57", "uts");

	function query($query) {
		global $conn;
		$result = mysqli_query($conn, $query);
		$rows = [];
		while( $row = mysqli_fetch_assoc($result) ) {
			$rows[] = $row;
		}
		return $rows;
	}

	function register($data){
		global $conn;

		$username = strtolower(stripslashes ($data["username"]));
		$email = strtolower(stripslashes($data["email"]));
		$password = mysqli_real_escape_string($conn, $data["password"]);
		$password2 = mysqli_real_escape_string($conn, $data["password2"]);

		//cek username sudah ada atau belum
		$result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
		if (mysqli_fetch_assoc($result)) {
			echo "<script>
					alert('username sudah terdaftar!')
				  </script>";
			return false;
		}
		//cek email sudah ada atau belum
		$result = mysqli_query($conn, "SELECT email FROM user WHERE email = '$email'");
		if (mysqli_fetch_assoc($result)) {
			echo"<script>
					alert('email sudah digunakan!')
				 </script>";
				 return false;

		}

		//cek konfirmasi password
		if ( $password !== $password2) {
			echo "<script>
					alert('konfirmasi password tidak sesuai');
				  </script>";
			return false;
		}

		//enkripsi password
		$password = password_hash($password, PASSWORD_DEFAULT);

		//tambahkan userbaru ke database
		mysqli_query($conn, "INSERT INTO user VALUES('', '$username','$email', '$password')");

		return mysqli_affected_rows($conn);
	}


	function tambah($data) {
		global $conn;

	//ambil data dari tiap elemen dalam form
	$daerah = htmlspecialchars($data["Daerah"]);
	$kasus = htmlspecialchars($data["Kasus"]);
	$meninggal = htmlspecialchars($data["Meninggal"]);
	$sembuh = htmlspecialchars($data["Sembuh"]);

	//query insert data
	$query = "INSERT INTO covid VALUES ('', '$daerah', '$kasus', '$meninggal', '$sembuh') ";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
	}


	function hapus ($id) {
		global $conn;
		mysqli_query($conn, "DELETE FROM covid WHERE id = $id");
		return mysqli_affected_rows($conn);
	}


	function ubah ($data) {
		global $conn;

		//ubah data dari tiap elemen dalam form
	$id = $data["id"];
	$daerah = htmlspecialchars($data["Daerah"]);
	$kasus = htmlspecialchars($data["Kasus"]);
	$meninggal = htmlspecialchars($data["Meninggal"]);
	$sembuh = htmlspecialchars($data["Sembuh"]);

	//query update data
	$query = "UPDATE  covid SET 
				Daerah = '$daerah',
				Kasus = '$kasus' ,
				Meninggal = '$meninggal',
				Sembuh = '$sembuh'
			  WHERE id = $id
				";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
	
	}


	function cari($keyword) {
		$query = "SELECT * FROM covid WHERE
					Daerah LIKE '%$keyword%' OR
					Kasus LIKE '%$keyword%' OR
					Meninggal LIKE '%$keyword%' OR
					Sembuh LIKE '%$keyword%'
				 ";
		return query($query);
	}


?>