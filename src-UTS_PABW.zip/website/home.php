<?php
//session_start();

//if (!isset($_SESSION["login"])) {
//	header("location:login.php");
//	exit();
//}
require 'koneksi.php';
$covid = query("SELECT * FROM covid");

//jika tombol cari ditekan
if ( isset($_POST["cari"]) ) {
  $covid = cari($_POST["keyword"]);
}

?>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Welcome</title>
  </head>
  <body>

    <header>
      <div class="container">
        <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-white">
  <a class="navbar-brand" href="#">Muhammad Hijrul Arifin Zain</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="logout.php">Logout <span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>
      </div>
    </header>
    

<!-- Awal Jumbotron -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid warna-bg text-white">
    <div class="container">
      <h1 class="display-4">Selamat Datang</h1>
        <p class="lead">Website ini merupakan website data COVID-19 yang ada di daerah-daerah Indonesia. Dan website ini bersumber dari https://kawalcovid19.id/</p>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron -->

<!-- Awal Content -->
<h2 align="center">
<strong> 
	<p>Kasus Virus COVID-19 Di Indonesia</p>
</strong>
</h2>

<div class="container" align="center">
<form action="" method="post">
  <input type="text" name="keyword" size="30" autofocus placeholder="Masukkan keyword pencarian......" autocomplete="off">
  <button type="submit" name="cari" class="btn-primary">Cari</button>
</form>
</div>

	<table align="center" border="1" cellpadding="10" cellspacing="0">
		<tr align="center">
			<th>Aksi</th>
      <th>Daerah</th>
			<th>Kasus</th>
			<th>Meninggal</th>
			<th>Sembuh</th>
		</tr>

		<?php foreach( $covid as $row ) : ?>
		<tr align="center">
			<td>
				<a href="ubah.php?id=<?= $row["id"]; ?>"=>Ubah</a> |
				<a href="hapus.php?id=<?= $row["id"]; ?>" onclick="return confirm('Anda Yakin Ingin Menghapus Data?') ">Hapus</a> |
        <a href="tambah.php">Tambah</a>
			</td>
      <td><?= $row["Daerah"]; ?></td>
			<td><?= $row["Kasus"]; ?></td>
			<td><?= $row["Meninggal"]; ?></td>
			<td><?= $row["Sembuh"]; ?></td>
		</tr>
		<?php endforeach; ?>

	</table>
<!-- Akhir Content -->


<!-- Awal Jumbotron2 -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid bg-light text-dark">
    <div class="container">
      <h2>Address</h2>
        <h1 class="lead">Jl. Guna Karya, Pekanbaru</h1>
        <h1 class="lead">South Sumatra, Indonesian</h1>
        <h1 class="lead">Email: zainaja91@gmail.com</h1>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron2 -->

<!-- Awal Footer -->
<footer class="warna-bg">
  <div class="text-white text-center pt-3 pb-3">Copyright @2020 Muhammad Hijrul Arifin Zain</div>
</footer>
<!-- Akhir Footer -->













    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="js/jquery-3.4.1.slim.min.js"></script>
    <script type="text/javascript" src="popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
  </body>
</html>