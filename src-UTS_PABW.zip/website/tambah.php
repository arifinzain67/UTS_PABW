<?php
// koneksi ke database
require 'koneksi.php';

// cek apakah tombol submit sudah ditekan atau belum
if ( isset($_POST["submit"]) ) {


	//cek apakah data berhasil ditambah atau tidak
	if ( tambah($_POST) > 0 ) {
		echo "
				<script>
				alert('Data Berhasil Di Tambahkan!');
				document.location.href = 'home.php';
				</script>
			 ";
			return false;
	} else {
		echo "
				<script>
				alert('Data Gagal Di Tambahkan!');
				document.location.href = 'home.php';
				</script>
			 ";
			return false;
	}
	
}
?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Tambah Data</title>
  </head>
  <body>

    <header>
      <div class="container">
        <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-white">
  <a class="navbar-brand" href="#">Muhammad Hijrul Arifin Zain</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="home.php">Back To Data<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>
      </div>
    </header>
    

<!-- Awal Jumbotron -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid warna-bg text-white">
    <div class="container">
      <h1 class="display-4">Menambah Data</h1>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron -->

<!-- Awal Content -->
<div class="container">
<form action="" method="post">
	 <div class="form-group">
      <label for="Daerah">Daerah</label>
      <input type="text" name="Daerah" id="Daerah" class="form-control" required>
    </div>
    <div class="form-group">
      <label for="Kasus">Kasus</label>
      <input type="text" name="Kasus" id="Kasus" class="form-control" required>
    </div>
    <div class="form-group">
      <label for="Meninggal">Meninggal</label>
      <input type="text" name="Meninggal" id="Meninggal" class="form-control" required>
    </div>
    <div class="form-group">
      <label for="Sembuh">Sembuh</label>
      <input type="text" name="Sembuh" id="Sembuh" class="form-control" required>
    </div>
    <button class="btn-primary active" type="submit" name="submit">
      Tambah Data!
    </button>

</form>
</div>
<!-- Akhir Content -->


<!-- Awal Jumbotron2 -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid bg-light text-dark">
    <div class="container">
      <h2>Address</h2>
        <h1 class="lead">Jl. Guna Karya, Pekanbaru</h1>
        <h1 class="lead">South Sumatra, Indonesian</h1>
        <h1 class="lead">Email: zainaja91@gmail.com</h1>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron2 -->

<!-- Awal Footer -->
<footer class="warna-bg">
  <div class="text-white text-center pt-3 pb-3">Copyright @2020 Muhammad Hijrul Arifin Zain</div>
</footer>
<!-- Akhir Footer -->













    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="js/jquery-3.4.1.slim.min.js"></script>
    <script type="text/javascript" src="popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
  </body>
</html>