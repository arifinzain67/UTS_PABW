 <?php
require 'koneksi.php'; 
	
	if (isset($_POST["register"])) {
		
		if (register($_POST) > 0) {
			echo 
			"<script>
					alert('user baru berhasil di tambahkan');
			</script>";
		} else {
			echo mysqli_error($conn);
		}
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Register</title>
  </head>
  <body>

    <header>
      <div class="container">
        <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-white">
  <a class="navbar-brand" href="#">Muhammad Hijrul Arifin Zain</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="login.php">Back To Login<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>
      </div>
    </header>
    

<!-- Awal Jumbotron -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid warna-bg text-white">
    <div class="container">
      <h1 class="display-4">REGISTER</h1>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron -->

<!-- Awal Content -->
<div class="container">
  <form action="" method="post">
    <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" id="username" class="form-control">
    </div>
    <div class="form-group">
      <label for="email">Email</label>
      <input type="text" name="email" id="email" class="form-control">
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" name="password" id="password" class="form-control">
    </div>
    <div class="form-group">
      <label for="password2">Konfirmasi Password</label>
      <input type="password" name="password2" id="password2" class="form-control">
    </div>
    <button class="btn-primary active" type="submit" name="register">
      Register
    </button>
  </form>
  <?php
    if(isset($_SESSION["message"])){
        echo $_SESSION["message"];
        unset($_SESSION["message"]);
    }
  ?>
  <br/>
  Already have account?<a href="login.php">Login here!</a>
</div>
<!-- Akhir Content -->


<!-- Awal Jumbotron2 -->
<section class="Jumbotron-bg">
  <div class="jumbotron jumbotron-fluid bg-light text-dark">
    <div class="container">
      <h2>Address</h2>
        <h1 class="lead">Jl. Guna Karya, Pekanbaru</h1>
        <h1 class="lead">South Sumatra, Indonesian</h1>
        <h1 class="lead">Email: zainaja91@gmail.com</h1>
    </div>
  </div>
</section>
<!-- Akhir Jumbotron2 -->

<!-- Awal Footer -->
<footer class="warna-bg">
  <div class="text-white text-center pt-3 pb-3">Copyright @2020 Muhammad Hijrul Arifin Zain</div>
</footer>
<!-- Akhir Footer -->













    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="js/jquery-3.4.1.slim.min.js"></script>
    <script type="text/javascript" src="popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
  </body>
</html>